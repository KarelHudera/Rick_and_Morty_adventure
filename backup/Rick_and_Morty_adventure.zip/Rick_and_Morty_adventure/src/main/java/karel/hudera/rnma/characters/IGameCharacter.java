package karel.hudera.rnma.characters;

public interface IGameCharacter {
    String speak();
    Boolean isAlive();
}